-- ================================================================
-- InfraPulse - Intelligent Road & Highway Management System
-- Database Schema
-- ================================================================

DROP DATABASE IF EXISTS infrapulse;
CREATE DATABASE infrapulse CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE infrapulse;

-- ================================================================
-- Table: roads
-- Purpose: Road infrastructure metadata
-- ================================================================
CREATE TABLE roads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    road_type ENUM('highway', 'urban', 'rural') NOT NULL,
    length_km FLOAT NOT NULL,
    age_years INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_road_type (road_type),
    INDEX idx_location (location)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- Table: traffic_events
-- Purpose: Real-time traffic data and patterns
-- ================================================================
CREATE TABLE traffic_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    road_id INT NOT NULL,
    avg_speed_kmh FLOAT NOT NULL,
    traffic_volume INT NOT NULL,
    congestion_level ENUM('low', 'medium', 'high') NOT NULL,
    recorded_at DATETIME NOT NULL,
    FOREIGN KEY (road_id) REFERENCES roads(id) ON DELETE CASCADE,
    INDEX idx_road_id (road_id),
    INDEX idx_recorded_at (recorded_at),
    INDEX idx_congestion (congestion_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- Table: incident_reports
-- Purpose: Operator/public incident reports
-- ================================================================
CREATE TABLE incident_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    road_id INT NOT NULL,
    description TEXT NOT NULL,
    source ENUM('operator', 'public', 'system') NOT NULL,
    reported_at DATETIME NOT NULL,
    FOREIGN KEY (road_id) REFERENCES roads(id) ON DELETE CASCADE,
    INDEX idx_road_id (road_id),
    INDEX idx_reported_at (reported_at),
    INDEX idx_source (source)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- Table: vibration_readings
-- Purpose: Road condition sensor data for degradation analysis
-- ================================================================
CREATE TABLE vibration_readings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    road_id INT NOT NULL,
    vibration_score FLOAT NOT NULL COMMENT 'Higher score indicates more degradation',
    recorded_at DATETIME NOT NULL,
    FOREIGN KEY (road_id) REFERENCES roads(id) ON DELETE CASCADE,
    INDEX idx_road_id (road_id),
    INDEX idx_recorded_at (recorded_at),
    INDEX idx_vibration_score (vibration_score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- Table: weather_logs
-- Purpose: Weather context data affecting road conditions
-- ================================================================
CREATE TABLE weather_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    road_id INT NOT NULL,
    weather_condition ENUM('clear', 'rain', 'storm', 'heatwave') NOT NULL,
    temperature_c FLOAT NOT NULL,
    recorded_at DATETIME NOT NULL,
    FOREIGN KEY (road_id) REFERENCES roads(id) ON DELETE CASCADE,
    INDEX idx_road_id (road_id),
    INDEX idx_recorded_at (recorded_at),
    INDEX idx_weather_condition (weather_condition)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- Table: ai_decisions
-- Purpose: AI decision history and recommendations
-- ================================================================
CREATE TABLE ai_decisions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    road_id INT NOT NULL,
    decision_type ENUM('incident', 'maintenance') NOT NULL,
    severity_or_risk VARCHAR(50) NOT NULL COMMENT 'Severity for incidents, Risk Level for maintenance',
    confidence_score FLOAT NOT NULL COMMENT 'AI confidence (0.0 to 1.0)',
    recommendation TEXT NOT NULL COMMENT 'JSON formatted AI recommendation',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (road_id) REFERENCES roads(id) ON DELETE CASCADE,
    INDEX idx_road_id (road_id),
    INDEX idx_decision_type (decision_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- End of Schema
-- ================================================================
