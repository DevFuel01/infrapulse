-- ================================================================
-- InfraPulse - Seed Data for Hackathon Demo
-- Realistic scenarios for AI decision testing
-- ================================================================

USE infrapulse;

-- ================================================================
-- Roads: Diverse infrastructure types
-- ================================================================
INSERT INTO roads (name, location, road_type, length_km, age_years) VALUES
('M1 Motorway North', 'London to Leeds', 'highway', 312.5, 45),
('A40 Western Avenue', 'Central London', 'urban', 18.2, 38),
('B4632 Country Road', 'Cotswolds Region', 'rural', 24.7, 52),
('M25 Orbital Section 4', 'Greater London', 'highway', 48.3, 28),
('Park Lane', 'Manchester City Center', 'urban', 3.8, 15),
('A303 Stonehenge Route', 'Wiltshire', 'rural', 92.4, 41),
('M6 Toll Road', 'Birmingham Bypass', 'highway', 43.2, 18);

-- ================================================================
-- Traffic Events: Various congestion scenarios
-- ================================================================
INSERT INTO traffic_events (road_id, avg_speed_kmh, traffic_volume, congestion_level, recorded_at) VALUES
-- M1 Motorway - Heavy morning traffic
(1, 45.2, 8500, 'high', '2026-01-20 08:30:00'),
(1, 68.5, 5200, 'medium', '2026-01-20 14:00:00'),
(1, 95.3, 2100, 'low', '2026-01-20 22:00:00'),

-- A40 Urban - Consistent high volume
(2, 28.4, 12000, 'high', '2026-01-20 09:00:00'),
(2, 32.1, 11500, 'high', '2026-01-20 17:30:00'),

-- B4632 Rural - Low traffic
(3, 72.8, 450, 'low', '2026-01-20 12:00:00'),
(3, 68.2, 380, 'low', '2026-01-20 16:00:00'),

-- M25 Orbital - Critical congestion
(4, 18.5, 15000, 'high', '2026-01-20 08:00:00'),
(4, 22.3, 14200, 'high', '2026-01-20 17:00:00'),

-- Park Lane - Moderate urban flow
(5, 38.6, 3200, 'medium', '2026-01-20 11:00:00'),

-- A303 Rural - Smooth flow
(6, 88.4, 1800, 'low', '2026-01-20 10:00:00'),

-- M6 Toll - Light traffic
(7, 105.2, 1200, 'low', '2026-01-20 13:00:00');

-- ================================================================
-- Incident Reports: Diverse incident types
-- ================================================================
INSERT INTO incident_reports (road_id, description, source, reported_at) VALUES
-- M1 - Multi-vehicle accident
(1, 'Multi-vehicle collision reported at Junction 23. Three vehicles involved, emergency services on scene. Heavy traffic buildup extending 5km northbound.', 'operator', '2026-01-20 08:15:00'),

-- A40 - Broken down vehicle
(2, 'Large delivery truck broken down in left lane near Perivale. Partially blocking traffic flow. Recovery vehicle dispatched.', 'system', '2026-01-20 09:30:00'),

-- B4632 - Debris on road
(3, 'Fallen tree branches blocking half of carriageway after overnight storm. Road still passable but hazardous.', 'public', '2026-01-20 07:45:00'),

-- M25 - Severe congestion
(4, 'Severe congestion due to earlier incident now cleared. Residual delays expected for 2+ hours. No current obstruction.', 'operator', '2026-01-20 09:00:00'),

-- Park Lane - Minor incident
(5, 'Minor fender bender at traffic lights. Vehicles moved to side. No lane blockage.', 'public', '2026-01-20 11:15:00'),

-- A303 - Weather related
(6, 'Heavy fog reducing visibility to less than 50 meters. Speed restrictions advised.', 'system', '2026-01-20 06:30:00');

-- ================================================================
-- Vibration Readings: Road degradation patterns
-- ================================================================
INSERT INTO vibration_readings (road_id, vibration_score, recorded_at) VALUES
-- M1 - Aging highway showing degradation
(1, 6.8, '2026-01-15 10:00:00'),
(1, 7.2, '2026-01-18 10:00:00'),
(1, 7.5, '2026-01-20 10:00:00'),

-- A40 - Urban stress, high vibration
(2, 8.4, '2026-01-15 11:00:00'),
(2, 8.7, '2026-01-18 11:00:00'),
(2, 9.1, '2026-01-20 11:00:00'),

-- B4632 - Old rural road, significant wear
(3, 9.5, '2026-01-15 12:00:00'),
(3, 9.8, '2026-01-18 12:00:00'),
(3, 10.2, '2026-01-20 12:00:00'),

-- M25 - Moderate degradation
(4, 5.2, '2026-01-15 13:00:00'),
(4, 5.4, '2026-01-18 13:00:00'),
(4, 5.6, '2026-01-20 13:00:00'),

-- Park Lane - Recently maintained, low vibration
(5, 2.1, '2026-01-15 14:00:00'),
(5, 2.2, '2026-01-18 14:00:00'),
(5, 2.3, '2026-01-20 14:00:00'),

-- A303 - Aging rural infrastructure
(6, 7.8, '2026-01-15 15:00:00'),
(6, 8.1, '2026-01-18 15:00:00'),
(6, 8.3, '2026-01-20 15:00:00'),

-- M6 Toll - Well maintained, minimal wear
(7, 3.2, '2026-01-15 16:00:00'),
(7, 3.3, '2026-01-18 16:00:00'),
(7, 3.4, '2026-01-20 16:00:00');

-- ================================================================
-- Weather Logs: Environmental conditions
-- ================================================================
INSERT INTO weather_logs (road_id, weather_condition, temperature_c, recorded_at) VALUES
-- M1 - Clear conditions
(1, 'clear', 8.5, '2026-01-20 08:00:00'),
(1, 'clear', 11.2, '2026-01-20 14:00:00'),

-- A40 - Urban heat
(2, 'clear', 12.4, '2026-01-20 09:00:00'),
(2, 'clear', 13.8, '2026-01-20 15:00:00'),

-- B4632 - Storm conditions
(3, 'storm', 6.2, '2026-01-20 07:00:00'),
(3, 'rain', 7.8, '2026-01-20 12:00:00'),

-- M25 - Rain affecting traffic
(4, 'rain', 9.5, '2026-01-20 08:00:00'),
(4, 'rain', 10.1, '2026-01-20 17:00:00'),

-- Park Lane - Clear
(5, 'clear', 13.2, '2026-01-20 11:00:00'),

-- A303 - Fog conditions
(6, 'rain', 5.8, '2026-01-20 06:00:00'),
(6, 'clear', 8.4, '2026-01-20 10:00:00'),

-- M6 Toll - Clear
(7, 'clear', 10.5, '2026-01-20 13:00:00');

-- ================================================================
-- End of Seed Data
-- ================================================================
