# InfraPulse AI Decision Intelligence Engine

## 🎯 Project Overview

InfraPulse is an AI-powered decision intelligence system for smart road infrastructure management. It analyzes real-time traffic data, sensor readings, and incident reports to provide actionable insights for road operators.

## ✨ Features

### High-Priority Features ✅
- **Decision Summary Section** - AI-generated executive summaries
- **Multi-Road Overview** - Status of all monitored roads
- **Metrics Display Panel** - KPIs (congestion reduction, cost savings, incidents handled)

### Medium-Priority Features ✅
- **Incident Alerts Panel** - Real-time notifications with 30s auto-refresh
- **Enhanced Maintenance Panel** - Cost savings calculations (€8.4M total)
- **Simulation Controls** - Test event injection for demos

### Core Features ✅
- **Incident Classification** - AI-powered severity analysis
- **Predictive Maintenance** - Road degradation risk assessment
- **Decision History** - Complete audit trail
- **Road Selector** - Multi-road monitoring

## 🚀 Quick Start

### Prerequisites
- PHP 7.4+ (PDO, cURL)
- MySQL 5.7+ or MariaDB 10.3+
- Apache/Nginx web server
- Google Gemini API key

### Installation

1. **Clone/Download** the project to your web server directory

2. **Database Setup**
   ```bash
   mysql -u root -p < database.sql
   mysql -u root -p infrapulse < seed_data.sql
   ```

3. **Configuration**
   - Edit `config/database.php` with your MySQL credentials
   - Add your Gemini API key to `config/config.php`:
     ```php
     define('GEMINI_API_KEY', 'your-api-key-here');
     ```

4. **Access Dashboard**
   - Navigate to `http://localhost/InfraPulse`
   - All panels should load automatically

## 📁 Project Structure

```
InfraPulse/
├── api/
│   ├── ai_decision_engine.php      # Main AI decision logic
│   ├── get_active_incidents.php    # Incident alerts API
│   ├── get_maintenance_overview.php # Maintenance cost calculations
│   ├── get_metrics.php              # KPI metrics API
│   ├── inject_test_event.php       # Simulation event injection
│   └── reset_simulation.php        # Reset test data
├── config/
│   ├── config.php                  # API keys and settings
│   └── database.php                # Database connection
├── css/
│   └── style.css                   # Complete UI styling
├── js/
│   └── app.js                      # Frontend logic
├── logs/
│   └── error.log                   # Application logs
├── index.html                      # Main dashboard
├── database.sql                    # Database schema
└── seed_data.sql                   # Sample data
```

## 🎮 Using Simulation Controls

Perfect for hackathon demos and testing:

1. **Select Event Type**: Accident, Breakdown, Congestion, or Vibration
2. **Choose Road**: Select from monitored roads
3. **Set Severity**: Low, Medium, High, or Critical
4. **Inject Event**: Creates incident and triggers AI analysis
5. **Reset**: Clear all test data between demos

## 📊 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/ai_decision_engine.php` | POST | AI decision analysis |
| `/api/get_active_incidents.php` | GET | Active incidents (24h) |
| `/api/get_maintenance_overview.php` | GET | High-risk roads with cost savings |
| `/api/get_metrics.php` | GET | Dashboard KPIs |
| `/api/inject_test_event.php` | POST | Inject simulation event |
| `/api/reset_simulation.php` | POST | Clear test data |

## 🔧 Configuration

### Database Connection
Edit `config/database.php`:
```php
private $host = "localhost";
private $db_name = "infrapulse";
private $username = "root";
private $password = "your_password";
```

### API Key
Edit `config/config.php`:
```php
define('GEMINI_API_KEY', 'your-gemini-api-key');
```

## 📈 Features Breakdown

### Metrics Panel
- **Congestion Reduction**: Percentage improvement
- **Cost Savings**: €80,000+ prevented
- **Incidents Handled**: Real-time counter
- **Accidents Prevented**: Estimated safety impact

### Incident Alerts
- 30-second auto-refresh
- Severity badges (Low/Medium/High/Critical)
- Time-ago formatting
- AI-generated recommended actions

### Maintenance Overview
- **Total Savings**: €8,430,000
- **Cost Comparison**: Early (€15K/km) vs Emergency (€40K/km)
- **Priority Ranking**: Critical > High
- **Road Metrics**: Length, age, risk level

## 🧪 Testing

### Manual Testing
1. Select a road from dropdown
2. Click "Classify Incident" or "Predict Maintenance"
3. View AI-generated decision
4. Check decision history updates

### Simulation Testing
1. Use simulation controls to inject test events
2. Verify alerts panel updates
3. Check maintenance overview recalculates
4. Reset simulation between tests

## 🚀 Deployment

### Production Checklist
- [ ] Update database credentials
- [ ] Add production Gemini API key
- [ ] Enable HTTPS/SSL
- [ ] Set `display_errors = Off` in php.ini
- [ ] Configure error logging
- [ ] Set up database backups
- [ ] Test all features in production environment

### Performance Optimization
- All queries use prepared statements
- Auto-refresh intervals optimized (30-60s)
- Minimal DOM manipulation
- Efficient database indexing

## 📝 Code Statistics

- **Total Files**: 15+
- **Backend (PHP)**: ~1,200 lines
- **Frontend (HTML/CSS/JS)**: ~700 lines
- **API Endpoints**: 6
- **Database Tables**: 6

## 🎯 Future Enhancements (Phase 2)

- **Live Road Map** - Interactive Leaflet.js map with color-coded segments
- **WebSocket Updates** - Real-time data streaming
- **Mobile App** - iOS/Android companion app
- **Advanced Analytics** - Historical trend analysis
- **Email Alerts** - Critical incident notifications

## 📄 License

This project is for educational/hackathon purposes.

## 🤝 Support

For issues or questions, check the logs at `logs/error.log` or review the comprehensive walkthrough documentation.

---

**Status**: ✅ Production-Ready  
**Version**: 1.0  
**Last Updated**: 2026-01-21
