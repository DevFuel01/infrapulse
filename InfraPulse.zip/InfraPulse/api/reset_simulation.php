<?php

/**
 * InfraPulse - Reset Simulation API
 * Clears all simulated/test data from the database
 */

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

$database = new Database();
$conn = $database->getConnection();

if (!$conn) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

try {
    // Delete simulated incident reports
    $stmt = $conn->prepare("DELETE FROM incident_reports WHERE source = 'simulation'");
    $stmt->execute();
    $incidentsDeleted = $stmt->rowCount();

    // Delete recent traffic events (last 1 hour)
    $stmt = $conn->prepare("DELETE FROM traffic_events WHERE recorded_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    $stmt->execute();
    $trafficDeleted = $stmt->rowCount();

    // Delete recent vibration data (last 1 hour)
    $stmt = $conn->prepare("DELETE FROM vibration_readings WHERE recorded_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    $stmt->execute();
    $vibrationDeleted = $stmt->rowCount();

    // Optionally delete recent AI decisions (last 1 hour)
    $stmt = $conn->prepare("DELETE FROM ai_decisions WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    $stmt->execute();
    $decisionsDeleted = $stmt->rowCount();

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'data' => [
            'incidents_deleted' => $incidentsDeleted,
            'traffic_events_deleted' => $trafficDeleted,
            'vibration_data_deleted' => $vibrationDeleted,
            'decisions_deleted' => $decisionsDeleted,
            'message' => 'Simulation data reset successfully'
        ]
    ]);
} catch (PDOException $e) {
    error_log("Reset Simulation Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to reset simulation']);
}
