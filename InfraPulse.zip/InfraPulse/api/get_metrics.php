<?php

/**
 * InfraPulse - Get Metrics API
 * Returns operational KPIs and performance metrics
 */

require_once __DIR__ . '/../config/config.php';

$database = new Database();
$conn = $database->getConnection();

if (!$conn) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

try {
    // Get time period (default: last 7 days)
    $days = $_GET['days'] ?? 7;

    // ============================================================
    // Metric 1: Traffic Congestion Reduction
    // ============================================================

    // Get average congestion before AI decisions (baseline)
    $baselineQuery = "SELECT AVG(CASE 
                        WHEN congestion_level = 'low' THEN 1
                        WHEN congestion_level = 'medium' THEN 2
                        WHEN congestion_level = 'high' THEN 3
                      END) as avg_congestion
                      FROM traffic_events
                      WHERE recorded_at < DATE_SUB(NOW(), INTERVAL :days DAY)";
    $stmt = $conn->prepare($baselineQuery);
    $stmt->bindValue(':days', (int)$days, PDO::PARAM_INT);
    $stmt->execute();
    $baseline = $stmt->fetch()['avg_congestion'] ?? 2.0;

    // Get current average congestion
    $currentQuery = "SELECT AVG(CASE 
                        WHEN congestion_level = 'low' THEN 1
                        WHEN congestion_level = 'medium' THEN 2
                        WHEN congestion_level = 'high' THEN 3
                      END) as avg_congestion
                      FROM traffic_events
                      WHERE recorded_at >= DATE_SUB(NOW(), INTERVAL :days DAY)";
    $stmt = $conn->prepare($currentQuery);
    $stmt->bindValue(':days', (int)$days, PDO::PARAM_INT);
    $stmt->execute();
    $current = $stmt->fetch()['avg_congestion'] ?? 2.0;

    // Calculate reduction percentage
    $congestionReduction = $baseline > 0 ? (($baseline - $current) / $baseline) * 100 : 0;
    $congestionReduction = max(0, min(100, round($congestionReduction, 1))); // Clamp 0-100

    // ============================================================
    // Metric 2: Maintenance Cost Prevented
    // ============================================================

    // Count high-risk roads identified
    $costQuery = "SELECT COUNT(*) as high_risk_count
                  FROM ai_decisions
                  WHERE decision_type = 'maintenance'
                  AND severity_or_risk = 'High'
                  AND created_at >= DATE_SUB(NOW(), INTERVAL :days DAY)";
    $stmt = $conn->prepare($costQuery);
    $stmt->bindValue(':days', (int)$days, PDO::PARAM_INT);
    $stmt->execute();
    $highRiskCount = $stmt->fetch()['high_risk_count'] ?? 0;

    // Estimate cost savings (early maintenance vs emergency repair)
    // Average cost difference: €40,000 per road
    $avgCostDifference = 40000;
    $costSavings = $highRiskCount * $avgCostDifference;

    // ============================================================
    // Metric 3: Incidents Handled
    // ============================================================

    $incidentsQuery = "SELECT COUNT(*) as incident_count
                       FROM ai_decisions
                       WHERE decision_type = 'incident'
                       AND created_at >= DATE_SUB(NOW(), INTERVAL :days DAY)";
    $stmt = $conn->prepare($incidentsQuery);
    $stmt->bindValue(':days', (int)$days, PDO::PARAM_INT);
    $stmt->execute();
    $incidentsHandled = $stmt->fetch()['incident_count'] ?? 0;

    // ============================================================
    // Metric 4: Accidents Prevented (Estimated)
    // ============================================================

    // Count critical incidents responded to quickly
    $criticalQuery = "SELECT COUNT(*) as critical_count
                      FROM ai_decisions
                      WHERE decision_type = 'incident'
                      AND (severity_or_risk = 'High' OR severity_or_risk = 'Critical')
                      AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
    $stmt = $conn->prepare($criticalQuery);
    $stmt->execute();
    $criticalIncidents = $stmt->fetch()['critical_count'] ?? 0;

    // Estimate: 25% of critical incidents would have escalated to accidents
    $accidentsPrevented = round($criticalIncidents * 0.25);

    // ============================================================
    // Metric 5: Total Decisions Made
    // ============================================================

    $totalQuery = "SELECT COUNT(*) as total_decisions
                   FROM ai_decisions
                   WHERE created_at >= DATE_SUB(NOW(), INTERVAL :days DAY)";
    $stmt = $conn->prepare($totalQuery);
    $stmt->bindValue(':days', (int)$days, PDO::PARAM_INT);
    $stmt->execute();
    $totalDecisions = $stmt->fetch()['total_decisions'] ?? 0;

    // ============================================================
    // Metric 6: Average Confidence Score
    // ============================================================

    $confidenceQuery = "SELECT AVG(confidence_score) as avg_confidence
                        FROM ai_decisions
                        WHERE created_at >= DATE_SUB(NOW(), INTERVAL :days DAY)";
    $stmt = $conn->prepare($confidenceQuery);
    $stmt->bindValue(':days', (int)$days, PDO::PARAM_INT);
    $stmt->execute();
    $avgConfidence = $stmt->fetch()['avg_confidence'] ?? 0;
    $avgConfidence = round($avgConfidence * 100, 1);

    // ============================================================
    // Build Response
    // ============================================================

    $metrics = [
        'congestion_reduction' => [
            'value' => $congestionReduction,
            'unit' => '%',
            'trend' => $congestionReduction > 0 ? 'up' : 'neutral',
            'label' => 'Congestion Reduced'
        ],
        'cost_savings' => [
            'value' => $costSavings,
            'unit' => '€',
            'trend' => $costSavings > 0 ? 'up' : 'neutral',
            'label' => 'Cost Savings',
            'formatted' => number_format($costSavings, 0, '.', ',')
        ],
        'incidents_handled' => [
            'value' => $incidentsHandled,
            'unit' => 'incidents',
            'period' => "last $days days",
            'label' => 'Incidents Handled'
        ],
        'accidents_prevented' => [
            'value' => $accidentsPrevented,
            'unit' => 'estimated',
            'period' => 'last 30 days',
            'label' => 'Accidents Prevented'
        ],
        'total_decisions' => [
            'value' => $totalDecisions,
            'unit' => 'decisions',
            'period' => "last $days days",
            'label' => 'AI Decisions Made'
        ],
        'avg_confidence' => [
            'value' => $avgConfidence,
            'unit' => '%',
            'label' => 'Average Confidence'
        ]
    ];

    http_response_code(200);
    echo json_encode(['success' => true, 'data' => $metrics, 'period_days' => $days]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to calculate metrics']);
}
