<?php

/**
 * InfraPulse - Get Maintenance Overview API
 * Returns all high-risk roads with cost savings calculations
 */

require_once __DIR__ . '/../config/config.php';

$database = new Database();
$conn = $database->getConnection();

if (!$conn) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

try {
    // Get all high-risk roads from recent AI decisions
    $query = "SELECT 
                ad.id as decision_id,
                ad.road_id,
                r.name as road_name,
                r.location,
                r.length_km,
                r.age_years,
                ad.severity_or_risk as risk_level,
                ad.recommendation,
                ad.confidence_score,
                ad.created_at
              FROM ai_decisions ad
              JOIN roads r ON ad.road_id = r.id
              WHERE ad.decision_type = 'maintenance'
              AND ad.severity_or_risk IN ('High', 'Critical')
              AND ad.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
              ORDER BY 
                CASE ad.severity_or_risk
                    WHEN 'Critical' THEN 1
                    WHEN 'High' THEN 2
                    ELSE 3
                END,
                ad.created_at DESC";

    $stmt = $conn->prepare($query);
    $stmt->execute();
    $roads = $stmt->fetchAll();

    // Cost calculation constants
    $EARLY_MAINTENANCE_COST_PER_KM = 15000;  // €15,000 per km
    $EMERGENCY_REPAIR_COST_PER_KM = 40000;   // €40,000 per km

    $totalSavings = 0;
    $formattedRoads = [];
    $priorityRank = 1;

    foreach ($roads as $road) {
        // Calculate costs
        $earlyCost = $road['length_km'] * $EARLY_MAINTENANCE_COST_PER_KM;
        $emergencyCost = $road['length_km'] * $EMERGENCY_REPAIR_COST_PER_KM;
        $potentialSavings = $emergencyCost - $earlyCost;
        $totalSavings += $potentialSavings;

        // Parse recommendation for urgency
        $urgency = 'Schedule Maintenance';
        $nextSteps = [];

        if ($road['recommendation']) {
            $recData = json_decode($road['recommendation'], true);
            if (isset($recData['urgency'])) {
                $urgency = $recData['urgency'];
            }
            if (isset($recData['recommended_next_steps'])) {
                $nextSteps = array_slice($recData['recommended_next_steps'], 0, 2);
            }
        }

        $formattedRoads[] = [
            'decision_id' => $road['decision_id'],
            'road_id' => $road['road_id'],
            'road_name' => $road['road_name'],
            'location' => $road['location'],
            'risk_level' => $road['risk_level'],
            'urgency' => $urgency,
            'length_km' => (float)$road['length_km'],
            'age_years' => (int)$road['age_years'],
            'early_cost' => $earlyCost,
            'emergency_cost' => $emergencyCost,
            'potential_savings' => $potentialSavings,
            'potential_savings_formatted' => number_format($potentialSavings, 0, '.', ','),
            'confidence_score' => (float)$road['confidence_score'],
            'priority_rank' => $priorityRank++,
            'recommended_next_steps' => $nextSteps,
            'last_assessed' => $road['created_at']
        ];
    }

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'data' => [
            'high_risk_roads' => $formattedRoads,
            'total_roads' => count($formattedRoads),
            'total_savings' => $totalSavings,
            'total_savings_formatted' => number_format($totalSavings, 0, '.', ','),
            'early_maintenance_cost_per_km' => $EARLY_MAINTENANCE_COST_PER_KM,
            'emergency_repair_cost_per_km' => $EMERGENCY_REPAIR_COST_PER_KM
        ]
    ]);
} catch (PDOException $e) {
    error_log("Get Maintenance Overview Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch maintenance overview']);
}
