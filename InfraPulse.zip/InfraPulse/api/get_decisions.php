<?php

/**
 * InfraPulse - Get Decisions API
 * Returns decision history with optional filtering
 */

require_once __DIR__ . '/../config/config.php';

$database = new Database();
$conn = $database->getConnection();

if (!$conn) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

try {
    $roadId = $_GET['road_id'] ?? null;
    $decisionType = $_GET['decision_type'] ?? null;
    $limit = $_GET['limit'] ?? 20;

    $query = "SELECT d.*, r.name as road_name, r.location 
              FROM ai_decisions d 
              JOIN roads r ON d.road_id = r.id 
              WHERE 1=1";

    $params = [];

    if ($roadId) {
        $query .= " AND d.road_id = :road_id";
        $params[':road_id'] = $roadId;
    }

    if ($decisionType) {
        $query .= " AND d.decision_type = :decision_type";
        $params[':decision_type'] = $decisionType;
    }

    $query .= " ORDER BY d.created_at DESC LIMIT :limit";

    $stmt = $conn->prepare($query);

    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);

    $stmt->execute();
    $decisions = $stmt->fetchAll();

    // Parse JSON recommendations
    foreach ($decisions as &$decision) {
        $decision['recommendation'] = json_decode($decision['recommendation'], true);
    }

    http_response_code(200);
    echo json_encode(['success' => true, 'data' => $decisions]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch decisions']);
}
