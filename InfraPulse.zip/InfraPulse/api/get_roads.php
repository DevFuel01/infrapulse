<?php

/**
 * InfraPulse - Get Roads API
 * Returns list of roads for dropdown population
 */

require_once __DIR__ . '/../config/config.php';

$database = new Database();
$conn = $database->getConnection();

if (!$conn) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

try {
    $query = "SELECT id, name, location, road_type, length_km, age_years FROM roads ORDER BY name ASC";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $roads = $stmt->fetchAll();

    http_response_code(200);
    echo json_encode(['success' => true, 'data' => $roads]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch roads']);
}
