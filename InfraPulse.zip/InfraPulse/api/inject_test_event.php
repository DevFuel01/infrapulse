<?php

/**
 * InfraPulse - Inject Test Event API
 * Injects simulated events for testing and demos
 */

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

$database = new Database();
$conn = $database->getConnection();

if (!$conn) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid request data']);
    exit;
}

$eventType = $input['event_type'] ?? 'accident';
$roadId = $input['road_id'] ?? 1;
$severity = $input['severity'] ?? 'Medium';
$autoClassify = $input['auto_classify'] ?? true;

try {
    // Generate event description based on type
    $descriptions = [
        'accident' => 'SIMULATED: Multi-vehicle collision reported. Emergency services dispatched.',
        'breakdown' => 'SIMULATED: Vehicle breakdown blocking lane. Recovery vehicle en route.',
        'congestion' => 'SIMULATED: Severe congestion spike detected. Traffic volume exceeding capacity.',
        'vibration' => 'SIMULATED: Vibration anomaly detected by sensors. Possible road degradation.'
    ];

    $description = $descriptions[$eventType] ?? $descriptions['accident'];

    // Insert incident report
    $incidentQuery = "INSERT INTO incident_reports (road_id, description, source, reported_at) 
                      VALUES (:road_id, :description, 'simulation', NOW())";
    $stmt = $conn->prepare($incidentQuery);
    $stmt->bindValue(':road_id', $roadId, PDO::PARAM_INT);
    $stmt->bindValue(':description', $description, PDO::PARAM_STR);
    $stmt->execute();
    $incidentId = $conn->lastInsertId();

    // Insert corresponding traffic event
    $congestionLevel = ($eventType === 'congestion' || $eventType === 'accident') ? 'high' : 'medium';
    $avgSpeed = ($eventType === 'congestion') ? 15.5 : 35.2;
    $trafficVolume = ($eventType === 'congestion') ? 15000 : 8000;

    $trafficQuery = "INSERT INTO traffic_events (road_id, avg_speed_kmh, traffic_volume, congestion_level, recorded_at)
                     VALUES (:road_id, :avg_speed, :traffic_volume, :congestion_level, NOW())";
    $stmt = $conn->prepare($trafficQuery);
    $stmt->bindValue(':road_id', $roadId, PDO::PARAM_INT);
    $stmt->bindValue(':avg_speed', $avgSpeed);
    $stmt->bindValue(':traffic_volume', $trafficVolume, PDO::PARAM_INT);
    $stmt->bindValue(':congestion_level', $congestionLevel, PDO::PARAM_STR);
    $stmt->execute();

    // Insert vibration data if vibration event
    if ($eventType === 'vibration') {
        $vibrationQuery = "INSERT INTO vibration_data (road_id, vibration_score, recorded_at)
                          VALUES (:road_id, 8.5, NOW())";
        $stmt = $conn->prepare($vibrationQuery);
        $stmt->bindValue(':road_id', $roadId, PDO::PARAM_INT);
        $stmt->execute();
    }

    // Auto-classify if requested
    $decisionId = null;
    if ($autoClassify) {
        // Trigger AI classification by calling the decision engine
        // For now, we'll just insert a simulated decision
        $decisionType = ($eventType === 'vibration') ? 'maintenance' : 'incident';

        $recommendation = json_encode([
            'recommended_actions' => [
                'Review simulated event data',
                'Verify system response',
                'Update traffic management plan'
            ]
        ]);

        $decisionQuery = "INSERT INTO ai_decisions 
                         (road_id, decision_type, severity_or_risk, confidence_score, recommendation, created_at)
                         VALUES (:road_id, :decision_type, :severity, 0.95, :recommendation, NOW())";
        $stmt = $conn->prepare($decisionQuery);
        $stmt->bindValue(':road_id', $roadId, PDO::PARAM_INT);
        $stmt->bindValue(':decision_type', $decisionType, PDO::PARAM_STR);
        $stmt->bindValue(':severity', $severity, PDO::PARAM_STR);
        $stmt->bindValue(':recommendation', $recommendation, PDO::PARAM_STR);
        $stmt->execute();
        $decisionId = $conn->lastInsertId();
    }

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'data' => [
            'incident_id' => $incidentId,
            'decision_id' => $decisionId,
            'event_type' => $eventType,
            'road_id' => $roadId,
            'severity' => $severity,
            'message' => 'Test event injected successfully'
        ]
    ]);
} catch (PDOException $e) {
    error_log("Inject Test Event Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to inject test event']);
}
