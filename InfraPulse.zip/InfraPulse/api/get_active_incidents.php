<?php

/**
 * InfraPulse - Get Active Incidents API
 * Returns current active incidents for alerts panel
 */

require_once __DIR__ . '/../config/config.php';

$database = new Database();
$conn = $database->getConnection();

if (!$conn) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

try {
    // Get active incidents from last 24 hours
    $query = "SELECT 
                ir.id,
                ir.road_id,
                r.name as road_name,
                ir.description,
                ir.source,
                ir.reported_at,
                TIMESTAMPDIFF(MINUTE, ir.reported_at, NOW()) as minutes_ago,
                ad.severity_or_risk as severity,
                ad.recommendation
              FROM incident_reports ir
              JOIN roads r ON ir.road_id = r.id
              LEFT JOIN ai_decisions ad ON ad.road_id = ir.road_id 
                AND ad.decision_type = 'incident'
                AND ad.created_at >= ir.reported_at
                AND ad.created_at <= DATE_ADD(ir.reported_at, INTERVAL 5 MINUTE)
              WHERE ir.reported_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
              ORDER BY ir.reported_at DESC
              LIMIT 10";

    $stmt = $conn->prepare($query);
    $stmt->execute();
    $incidents = $stmt->fetchAll();

    // Format incidents with time ago
    $formattedIncidents = array_map(function ($incident) {
        $minutesAgo = $incident['minutes_ago'];

        if ($minutesAgo < 1) {
            $timeAgo = 'Just now';
        } elseif ($minutesAgo < 60) {
            $timeAgo = $minutesAgo . ' minute' . ($minutesAgo > 1 ? 's' : '') . ' ago';
        } else {
            $hoursAgo = floor($minutesAgo / 60);
            $timeAgo = $hoursAgo . ' hour' . ($hoursAgo > 1 ? 's' : '') . ' ago';
        }

        // Determine incident type from description
        $description = strtolower($incident['description']);
        $incidentType = 'unknown';

        if (strpos($description, 'accident') !== false || strpos($description, 'collision') !== false) {
            $incidentType = 'accident';
        } elseif (strpos($description, 'breakdown') !== false) {
            $incidentType = 'breakdown';
        } elseif (strpos($description, 'obstruction') !== false || strpos($description, 'debris') !== false) {
            $incidentType = 'obstruction';
        } elseif (strpos($description, 'weather') !== false || strpos($description, 'storm') !== false || strpos($description, 'rain') !== false) {
            $incidentType = 'weather_related';
        }

        // Parse recommendation if available
        $actions = [];
        if ($incident['recommendation']) {
            $recData = json_decode($incident['recommendation'], true);
            if (isset($recData['recommended_actions'])) {
                $actions = array_slice($recData['recommended_actions'], 0, 2); // First 2 actions
            }
        }

        return [
            'id' => $incident['id'],
            'road_id' => $incident['road_id'],
            'road_name' => $incident['road_name'],
            'incident_type' => $incidentType,
            'severity' => $incident['severity'] ?? 'Medium',
            'description' => $incident['description'],
            'source' => $incident['source'],
            'reported_at' => $incident['reported_at'],
            'time_ago' => $timeAgo,
            'recommended_actions' => $actions
        ];
    }, $incidents);

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'data' => $formattedIncidents,
        'count' => count($formattedIncidents)
    ]);
} catch (PDOException $e) {
    error_log("Get Active Incidents Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch incidents']);
}
