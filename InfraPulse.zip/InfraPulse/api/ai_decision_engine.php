<?php

/**
 * InfraPulse - AI Decision Intelligence Engine
 * Core API endpoint for incident classification, predictive maintenance, and executive summaries
 * 
 * This is a production-grade decision support component.
 * Frontend NEVER talks to Gemini directly - all AI requests flow through this API.
 */

require_once __DIR__ . '/../config/config.php';

/**
 * Main AI Decision Engine Class
 */
class AIDecisionEngine
{
    private $db;
    private $conn;

    public function __construct()
    {
        $this->db = new Database();
        $this->conn = $this->db->getConnection();
    }

    /**
     * Process decision request based on type
     */
    public function processDecision($data)
    {
        if (!$this->conn) {
            return $this->errorResponse("Database connection failed");
        }

        $decisionType = $data['decision_type'] ?? null;
        $roadId = $data['road_id'] ?? null;

        if (!$decisionType) {
            return $this->errorResponse("Missing decision_type parameter");
        }

        if (!$roadId) {
            return $this->errorResponse("Missing road_id parameter");
        }

        switch ($decisionType) {
            case 'incident':
                return $this->classifyIncident($roadId, $data['incident_id'] ?? null);

            case 'maintenance':
                return $this->predictMaintenance($roadId);

            case 'summary':
                return $this->generateSummary($roadId, $data['decision_id'] ?? null);

            default:
                return $this->errorResponse("Invalid decision_type. Must be: incident, maintenance, or summary");
        }
    }

    /**
     * TASK 1: Incident Classification & Response Decision
     */
    private function classifyIncident($roadId, $incidentId = null)
    {
        // Gather contextual data
        $roadData = $this->getRoadData($roadId);
        if (!$roadData) {
            return $this->errorResponse("Road not found");
        }

        $trafficData = $this->getRecentTrafficData($roadId);
        $incidentData = $this->getIncidentData($roadId, $incidentId);
        $weatherData = $this->getRecentWeatherData($roadId);

        // Build AI prompt
        $prompt = $this->buildIncidentPrompt($roadData, $trafficData, $incidentData, $weatherData);

        // Call Gemini API
        $aiResponse = $this->callGeminiAPI($prompt);

        if (!$aiResponse) {
            return $this->errorResponse("AI service unavailable");
        }

        // Parse and validate response
        $decision = $this->parseJSONResponse($aiResponse);

        if (!$decision) {
            return $this->errorResponse("Invalid AI response format");
        }

        // Store decision in database
        $this->storeDecision($roadId, 'incident', $decision['severity'], $decision['confidence_score'], json_encode($decision));

        return $this->successResponse($decision);
    }

    /**
     * TASK 2: Predictive Road Maintenance Decision
     */
    private function predictMaintenance($roadId)
    {
        // Gather contextual data
        $roadData = $this->getRoadData($roadId);
        if (!$roadData) {
            return $this->errorResponse("Road not found");
        }

        $vibrationData = $this->getVibrationTrends($roadId);
        $trafficData = $this->getTrafficLoadHistory($roadId);
        $weatherData = $this->getWeatherExposure($roadId);

        // Build AI prompt
        $prompt = $this->buildMaintenancePrompt($roadData, $vibrationData, $trafficData, $weatherData);

        // Call Gemini API
        $aiResponse = $this->callGeminiAPI($prompt);

        if (!$aiResponse) {
            return $this->errorResponse("AI service unavailable");
        }

        // Parse and validate response
        $decision = $this->parseJSONResponse($aiResponse);

        if (!$decision) {
            return $this->errorResponse("Invalid AI response format");
        }

        // Store decision in database
        $this->storeDecision($roadId, 'maintenance', $decision['risk_level'], $decision['confidence_score'], json_encode($decision));

        return $this->successResponse($decision);
    }

    /**
     * TASK 3: Executive Decision Summary
     */
    private function generateSummary($roadId, $decisionId = null)
    {
        if ($decisionId) {
            $decisionData = $this->getDecisionById($decisionId);
        } else {
            $decisionData = $this->getLatestDecision($roadId);
        }

        if (!$decisionData) {
            return $this->errorResponse("No decision found");
        }

        $prompt = $this->buildSummaryPrompt($decisionData);
        $aiResponse = $this->callGeminiAPI($prompt);

        if (!$aiResponse) {
            return $this->errorResponse("AI service unavailable");
        }

        $summary = $this->parseJSONResponse($aiResponse);

        if (!$summary) {
            return $this->errorResponse("Invalid AI response format");
        }

        return $this->successResponse($summary);
    }

    /**
     * Build incident classification prompt
     */
    private function buildIncidentPrompt($road, $traffic, $incident, $weather)
    {
        $currentTime = date('Y-m-d H:i:s');
        $timeOfDay = date('H:i');

        $systemPrompt = "You are a decision intelligence engine for infrastructure management. You analyze road data and return clear, actionable operational decisions. You MUST respond ONLY with valid JSON. No explanations, no markdown, no additional text.";

        $userPrompt = "INCIDENT CLASSIFICATION TASK\n\n";
        $userPrompt .= "ROAD METADATA:\n";
        $userPrompt .= "- Name: {$road['name']}\n";
        $userPrompt .= "- Location: {$road['location']}\n";
        $userPrompt .= "- Type: {$road['road_type']}\n";
        $userPrompt .= "- Length: {$road['length_km']} km\n";
        $userPrompt .= "- Age: {$road['age_years']} years\n\n";

        if (!empty($traffic)) {
            $userPrompt .= "RECENT TRAFFIC PATTERNS:\n";
            foreach ($traffic as $t) {
                $userPrompt .= "- {$t['recorded_at']}: Speed {$t['avg_speed_kmh']} km/h, Volume {$t['traffic_volume']}, Congestion: {$t['congestion_level']}\n";
            }
            $userPrompt .= "\n";
        }

        if (!empty($incident)) {
            $userPrompt .= "INCIDENT REPORTS:\n";
            foreach ($incident as $i) {
                $userPrompt .= "- [{$i['source']}] {$i['reported_at']}: {$i['description']}\n";
            }
            $userPrompt .= "\n";
        }

        if (!empty($weather)) {
            $userPrompt .= "WEATHER CONTEXT:\n";
            foreach ($weather as $w) {
                $userPrompt .= "- {$w['recorded_at']}: {$w['weather_condition']}, {$w['temperature_c']}°C\n";
            }
            $userPrompt .= "\n";
        }

        $userPrompt .= "CURRENT TIME: {$currentTime} (Time of day: {$timeOfDay})\n\n";
        $userPrompt .= "ANALYZE THE DATA AND RESPOND WITH STRICT JSON ONLY:\n";
        $userPrompt .= "{\n";
        $userPrompt .= '  "incident_type": "accident | breakdown | obstruction | weather_related | unknown",' . "\n";
        $userPrompt .= '  "severity": "Low | Medium | High | Critical",' . "\n";
        $userPrompt .= '  "confidence_score": 0.85,' . "\n";
        $userPrompt .= '  "expected_impact": "short concrete description",' . "\n";
        $userPrompt .= '  "recommended_actions": ["action 1", "action 2"]' . "\n";
        $userPrompt .= "}\n\n";
        $userPrompt .= "RULES:\n";
        $userPrompt .= "- Be conservative and realistic\n";
        $userPrompt .= "- If data is insufficient, state uncertainty in confidence_score\n";
        $userPrompt .= "- Provide actionable recommendations for operators\n";
        $userPrompt .= "- Return ONLY valid JSON, no other text";

        return ['system' => $systemPrompt, 'user' => $userPrompt];
    }

    /**
     * Build maintenance prediction prompt
     */
    private function buildMaintenancePrompt($road, $vibration, $traffic, $weather)
    {
        $systemPrompt = "You are a decision intelligence engine for infrastructure management. You analyze road data and return clear, actionable operational decisions. You MUST respond ONLY with valid JSON. No explanations, no markdown, no additional text.";

        $userPrompt = "PREDICTIVE MAINTENANCE TASK\n\n";
        $userPrompt .= "ROAD METADATA:\n";
        $userPrompt .= "- Name: {$road['name']}\n";
        $userPrompt .= "- Location: {$road['location']}\n";
        $userPrompt .= "- Type: {$road['road_type']}\n";
        $userPrompt .= "- Length: {$road['length_km']} km\n";
        $userPrompt .= "- Age: {$road['age_years']} years\n\n";

        if (!empty($vibration)) {
            $userPrompt .= "VIBRATION TRENDS (degradation indicator):\n";
            foreach ($vibration as $v) {
                $userPrompt .= "- {$v['recorded_at']}: Score {$v['vibration_score']} (higher = more degradation)\n";
            }
            $userPrompt .= "\n";
        }

        if (!empty($traffic)) {
            $userPrompt .= "TRAFFIC LOAD HISTORY:\n";
            foreach ($traffic as $t) {
                $userPrompt .= "- {$t['recorded_at']}: Volume {$t['traffic_volume']}, Congestion: {$t['congestion_level']}\n";
            }
            $userPrompt .= "\n";
        }

        if (!empty($weather)) {
            $userPrompt .= "WEATHER EXPOSURE:\n";
            foreach ($weather as $w) {
                $userPrompt .= "- {$w['recorded_at']}: {$w['weather_condition']}, {$w['temperature_c']}°C\n";
            }
            $userPrompt .= "\n";
        }

        $userPrompt .= "ANALYZE THE DATA AND RESPOND WITH STRICT JSON ONLY:\n";
        $userPrompt .= "{\n";
        $userPrompt .= '  "risk_level": "Low | Medium | High",' . "\n";
        $userPrompt .= '  "urgency": "Monitor | Schedule Maintenance | Immediate Action",' . "\n";
        $userPrompt .= '  "confidence_score": 0.85,' . "\n";
        $userPrompt .= '  "justification": "clear non-technical explanation",' . "\n";
        $userPrompt .= '  "recommended_next_steps": ["step 1", "step 2"]' . "\n";
        $userPrompt .= "}\n\n";
        $userPrompt .= "RULES:\n";
        $userPrompt .= "- Be conservative and realistic\n";
        $userPrompt .= "- Consider road age, vibration trends, traffic load, and weather\n";
        $userPrompt .= "- Provide clear justification understandable by decision-makers\n";
        $userPrompt .= "- Return ONLY valid JSON, no other text";

        return ['system' => $systemPrompt, 'user' => $userPrompt];
    }

    /**
     * Build executive summary prompt
     */
    private function buildSummaryPrompt($decision)
    {
        $systemPrompt = "You are a decision intelligence engine for infrastructure management. You create concise executive summaries. You MUST respond ONLY with valid JSON. No explanations, no markdown, no additional text.";

        $userPrompt = "EXECUTIVE SUMMARY TASK\n\n";
        $userPrompt .= "DECISION DATA:\n";
        $userPrompt .= json_encode($decision, JSON_PRETTY_PRINT);
        $userPrompt .= "\n\nGenerate a short summary for dashboards or reports.\n\n";
        $userPrompt .= "RESPOND WITH STRICT JSON ONLY:\n";
        $userPrompt .= "{\n";
        $userPrompt .= '  "decision_summary": "Maximum 3 sentences. No technical jargon. Focus on actions and consequences."' . "\n";
        $userPrompt .= "}\n\n";
        $userPrompt .= "Return ONLY valid JSON, no other text";

        return ['system' => $systemPrompt, 'user' => $userPrompt];
    }

    /**
     * Call Gemini API
     */
    private function callGeminiAPI($prompt)
    {
        $apiKey = GEMINI_API_KEY;

        if ($apiKey === 'YOUR_GEMINI_API_KEY_HERE') {
            // Return mock response for testing without API key
            return $this->getMockResponse();
        }

        $url = GEMINI_API_ENDPOINT . '?key=' . $apiKey;

        $payload = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt['system'] . "\n\n" . $prompt['user']]
                    ]
                ]
            ],
            'generationConfig' => [
                'temperature' => 0.3,
                'topK' => 1,
                'topP' => 0.8,
                'maxOutputTokens' => 2048,
            ]
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json'
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            error_log("Gemini API Error: HTTP $httpCode - $response");
            return null;
        }

        $data = json_decode($response, true);

        if (isset($data['candidates'][0]['content']['parts'][0]['text'])) {
            $aiText = $data['candidates'][0]['content']['parts'][0]['text'];
            // Log the full AI response for debugging
            error_log("Gemini AI Response: " . $aiText);
            return $aiText;
        }

        // Log the full response if text not found
        error_log("Gemini API Response (no text found): " . $response);
        return null;
    }

    /**
     * Mock response for testing without API key
     */
    private function getMockResponse()
    {
        // This will be replaced with actual Gemini response when API key is configured
        return json_encode([
            'incident_type' => 'accident',
            'severity' => 'High',
            'confidence_score' => 0.85,
            'expected_impact' => 'Significant traffic delays expected for 2-3 hours',
            'recommended_actions' => [
                'Deploy emergency services to scene',
                'Activate electronic signage to divert traffic',
                'Monitor traffic flow and adjust signals'
            ]
        ]);
    }

    /**
     * Parse JSON response from AI
     */
    private function parseJSONResponse($response)
    {
        // Remove markdown code blocks if present
        $response = preg_replace('/```json\s*/', '', $response);
        $response = preg_replace('/```\s*/', '', $response);
        $response = trim($response);

        // Check if response looks incomplete (missing closing brace)
        $openBraces = substr_count($response, '{');
        $closeBraces = substr_count($response, '}');

        if ($openBraces > $closeBraces) {
            error_log("Incomplete JSON detected - missing closing braces. Response: " . $response);
            // Try to close the JSON
            $response .= str_repeat('}', $openBraces - $closeBraces);
        }

        $data = json_decode($response, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("JSON Parse Error: " . json_last_error_msg() . " - Response: " . $response);
            return null;
        }

        return $data;
    }

    /**
     * Store decision in database
     */
    private function storeDecision($roadId, $type, $severityOrRisk, $confidence, $recommendation)
    {
        $query = "INSERT INTO ai_decisions (road_id, decision_type, severity_or_risk, confidence_score, recommendation, created_at) 
                  VALUES (:road_id, :decision_type, :severity_or_risk, :confidence_score, :recommendation, NOW())";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':road_id', $roadId);
        $stmt->bindParam(':decision_type', $type);
        $stmt->bindParam(':severity_or_risk', $severityOrRisk);
        $stmt->bindParam(':confidence_score', $confidence);
        $stmt->bindParam(':recommendation', $recommendation);

        return $stmt->execute();
    }

    // ============================================================
    // DATA RETRIEVAL METHODS
    // ============================================================

    private function getRoadData($roadId)
    {
        $query = "SELECT * FROM roads WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $roadId);
        $stmt->execute();
        return $stmt->fetch();
    }

    private function getRecentTrafficData($roadId, $hours = 24)
    {
        $query = "SELECT * FROM traffic_events 
                  WHERE road_id = :road_id 
                  AND recorded_at >= DATE_SUB(NOW(), INTERVAL :hours HOUR)
                  ORDER BY recorded_at DESC LIMIT 10";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':road_id', $roadId);
        $stmt->bindParam(':hours', $hours);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    private function getIncidentData($roadId, $incidentId = null)
    {
        if ($incidentId) {
            $query = "SELECT * FROM incident_reports WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $incidentId);
        } else {
            $query = "SELECT * FROM incident_reports 
                      WHERE road_id = :road_id 
                      AND reported_at >= DATE_SUB(NOW(), INTERVAL 6 HOUR)
                      ORDER BY reported_at DESC LIMIT 5";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':road_id', $roadId);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    }

    private function getRecentWeatherData($roadId, $hours = 12)
    {
        $query = "SELECT * FROM weather_logs 
                  WHERE road_id = :road_id 
                  AND recorded_at >= DATE_SUB(NOW(), INTERVAL :hours HOUR)
                  ORDER BY recorded_at DESC LIMIT 5";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':road_id', $roadId);
        $stmt->bindParam(':hours', $hours);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    private function getVibrationTrends($roadId, $days = 7)
    {
        $query = "SELECT * FROM vibration_readings 
                  WHERE road_id = :road_id 
                  AND recorded_at >= DATE_SUB(NOW(), INTERVAL :days DAY)
                  ORDER BY recorded_at ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':road_id', $roadId);
        $stmt->bindParam(':days', $days);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    private function getTrafficLoadHistory($roadId, $days = 30)
    {
        $query = "SELECT * FROM traffic_events 
                  WHERE road_id = :road_id 
                  AND recorded_at >= DATE_SUB(NOW(), INTERVAL :days DAY)
                  ORDER BY recorded_at DESC LIMIT 20";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':road_id', $roadId);
        $stmt->bindParam(':days', $days);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    private function getWeatherExposure($roadId, $days = 30)
    {
        $query = "SELECT * FROM weather_logs 
                  WHERE road_id = :road_id 
                  AND recorded_at >= DATE_SUB(NOW(), INTERVAL :days DAY)
                  ORDER BY recorded_at DESC LIMIT 20";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':road_id', $roadId);
        $stmt->bindParam(':days', $days);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    private function getDecisionById($decisionId)
    {
        $query = "SELECT * FROM ai_decisions WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $decisionId);
        $stmt->execute();
        return $stmt->fetch();
    }

    private function getLatestDecision($roadId)
    {
        $query = "SELECT * FROM ai_decisions WHERE road_id = :road_id ORDER BY created_at DESC LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':road_id', $roadId);
        $stmt->execute();
        return $stmt->fetch();
    }

    // ============================================================
    // RESPONSE HELPERS
    // ============================================================

    private function successResponse($data)
    {
        http_response_code(200);
        return json_encode(['success' => true, 'data' => $data]);
    }

    private function errorResponse($message)
    {
        http_response_code(400);
        return json_encode(['success' => false, 'error' => $message]);
    }
}

// ============================================================
// API ENDPOINT HANDLER
// ============================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (!$data) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid JSON input']);
        exit;
    }

    $engine = new AIDecisionEngine();
    echo $engine->processDecision($data);
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed. Use POST.']);
}
