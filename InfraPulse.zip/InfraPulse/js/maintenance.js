
// ============================================================
// Maintenance Overview Panel
// ============================================================

async function loadMaintenanceOverview() {
    try {
        const response = await fetch('api/get_maintenance_overview.php');
        const data = await response.json();

        if (data.success) {
            displayMaintenanceOverview(data.data);
        } else {
            console.error('Maintenance Overview API error:', data.error);
        }
    } catch (error) {
        console.error('Error loading maintenance overview:', error);
    }
}

function displayMaintenanceOverview(data) {
    const container = document.getElementById('maintenanceOverviewContainer');
    const totalSavings = document.getElementById('totalSavings');
    const highRiskCount = document.getElementById('highRiskCount');
    
    // Update summary
    if (totalSavings) {
        totalSavings.textContent = '€' + data.total_savings_formatted;
    }
    if (highRiskCount) {
        highRiskCount.textContent = data.total_roads;
    }
    
    if (!container) return;
    
    // Show empty state if no high-risk roads
    if (data.high_risk_roads.length === 0) {
        container.innerHTML = `
            <div class="alerts-empty">
                <div class="alerts-empty-icon">✓</div>
                <p>No high-risk roads requiring immediate attention</p>
            </div>
        `;
        return;
    }
    
    // Display maintenance road cards
    container.innerHTML = data.high_risk_roads.map(road => {
        const riskClass = `risk-${road.risk_level.toLowerCase()}`;
        
        let nextStepsHTML = '';
        if (road.recommended_next_steps && road.recommended_next_steps.length > 0) {
            nextStepsHTML = `
                <div class="alert-actions">
                    ${road.recommended_next_steps.map(step => 
                        `<div class="alert-action">${step}</div>`
                    ).join('')}
                </div>
            `;
        }
        
        return `
            <div class="maintenance-road-card ${riskClass}">
                <div class="maintenance-header">
                    <span class="maintenance-road-name">${road.road_name}</span>
                    <span class="maintenance-priority">Priority #${road.priority_rank}</span>
                </div>
                
                <div class="maintenance-details">
                    <div class="maintenance-detail-item">
                        <span class="maintenance-detail-label">Risk Level</span>
                        <span class="badge badge-${road.risk_level.toLowerCase()}">${road.risk_level}</span>
                    </div>
                    <div class="maintenance-detail-item">
                        <span class="maintenance-detail-label">Urgency</span>
                        <span class="maintenance-detail-value">${road.urgency}</span>
                    </div>
                    <div class="maintenance-detail-item">
                        <span class="maintenance-detail-label">Length</span>
                        <span class="maintenance-detail-value">${road.length_km} km</span>
                    </div>
                    <div class="maintenance-detail-item">
                        <span class="maintenance-detail-label">Age</span>
                        <span class="maintenance-detail-value">${road.age_years} years</span>
                    </div>
                </div>
                
                <div class="cost-comparison">
                    <div class="cost-item">
                        <span class="cost-label">Early Maintenance</span>
                        <span class="cost-value early">€${formatNumber(road.early_cost)}</span>
                    </div>
                    <div class="cost-item">
                        <span class="cost-label">Emergency Repair</span>
                        <span class="cost-value emergency">€${formatNumber(road.emergency_cost)}</span>
                    </div>
                    <div class="cost-item">
                        <span class="cost-label">Potential Savings</span>
                        <span class="cost-value savings">€${road.potential_savings_formatted}</span>
                    </div>
                </div>
                
                ${nextStepsHTML}
            </div>
        `;
    }).join('');
}

function formatNumber(num) {
    return new Intl.NumberFormat('en-US').format(Math.round(num));
}
