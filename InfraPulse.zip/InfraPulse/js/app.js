/**
 * InfraPulse - Frontend Application Logic
 * Handles AJAX calls to backend API and dynamic UI updates
 */

// Global state
let selectedRoadId = null;
let roads = [];

// ============================================================
// Initialization
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    loadRoads();
    setupEventListeners();
    loadDecisionHistory();
    loadMetrics(); // Load metrics on page load
    loadActiveIncidents(); // Load incident alerts
    loadMaintenanceOverview(); // Load maintenance overview
    loadLatestSummary(); // Load latest decision summary
    
    // Setup simulation controls after roads are loaded
    setTimeout(setupSimulationControls, 500);
    
    setInterval(loadMetrics, 60000); // Refresh metrics every minute
    setInterval(loadActiveIncidents, 30000); // Refresh alerts every 30 seconds
    setInterval(loadMaintenanceOverview, 60000); // Refresh maintenance every minute
});

// ============================================================
// Event Listeners
// ============================================================

function setupEventListeners() {
    const roadSelect = document.getElementById('roadSelect');
    const classifyBtn = document.getElementById('classifyIncidentBtn');
    const predictBtn = document.getElementById('predictMaintenanceBtn');
    const refreshBtn = document.getElementById('refreshHistoryBtn');
    const historyFilter = document.getElementById('historyFilter');

    roadSelect.addEventListener('change', handleRoadSelection);
    classifyBtn.addEventListener('click', () => classifyIncident());
    predictBtn.addEventListener('click', () => predictMaintenance());
    refreshBtn.addEventListener('click', () => loadDecisionHistory());
    historyFilter.addEventListener('change', () => loadDecisionHistory());
}

// ============================================================
// Road Management
// ============================================================

async function loadRoads() {
    try {
        const response = await fetch('api/get_roads.php');
        const data = await response.json();

        if (data.success) {
            roads = data.data;
            populateRoadSelect(roads);
        } else {
            showError('Failed to load roads');
        }
    } catch (error) {
        console.error('Error loading roads:', error);
        showError('Network error loading roads');
    }
}

function populateRoadSelect(roads) {
    const select = document.getElementById('roadSelect');
    select.innerHTML = '<option value="">-- Select a road --</option>';

    roads.forEach(road => {
        const option = document.createElement('option');
        option.value = road.id;
        option.textContent = `${road.name} (${road.location})`;
        option.dataset.road = JSON.stringify(road);
        select.appendChild(option);
    });
}

function handleRoadSelection(event) {
    const select = event.target;
    const selectedOption = select.options[select.selectedIndex];

    if (selectedOption.value) {
        selectedRoadId = selectedOption.value;
        const road = JSON.parse(selectedOption.dataset.road);
        displayRoadInfo(road);
        enableDecisionButtons();
    } else {
        selectedRoadId = null;
        clearRoadInfo();
        disableDecisionButtons();
    }
}

function displayRoadInfo(road) {
    const roadInfo = document.getElementById('roadInfo');
    roadInfo.innerHTML = `
        <strong>${road.name}</strong> • 
        ${road.road_type.charAt(0).toUpperCase() + road.road_type.slice(1)} • 
        ${road.length_km} km • 
        ${road.age_years} years old
    `;
}

function clearRoadInfo() {
    document.getElementById('roadInfo').innerHTML = '';
}

function enableDecisionButtons() {
    document.getElementById('classifyIncidentBtn').disabled = false;
    document.getElementById('predictMaintenanceBtn').disabled = false;
}

function disableDecisionButtons() {
    document.getElementById('classifyIncidentBtn').disabled = true;
    document.getElementById('predictMaintenanceBtn').disabled = true;
}

// ============================================================
// AI Decision Requests
// ============================================================

async function classifyIncident() {
    if (!selectedRoadId) return;

    showLoading(true);

    try {
        const response = await fetch('api/ai_decision_engine.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                decision_type: 'incident',
                road_id: selectedRoadId
            })
        });

        const data = await response.json();

        if (data.success) {
            displayIncidentResult(data.data);
            loadDecisionHistory(); // Refresh history
        } else {
            showError(data.error || 'Failed to classify incident');
        }
    } catch (error) {
        console.error('Error classifying incident:', error);
        showError('Network error during incident classification');
    } finally {
        showLoading(false);
    }
}

async function predictMaintenance() {
    if (!selectedRoadId) return;

    showLoading(true);

    try {
        const response = await fetch('api/ai_decision_engine.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                decision_type: 'maintenance',
                road_id: selectedRoadId
            })
        });

        const data = await response.json();

        if (data.success) {
            displayMaintenanceResult(data.data);
            loadDecisionHistory(); // Refresh history
        } else {
            showError(data.error || 'Failed to predict maintenance');
        }
    } catch (error) {
        console.error('Error predicting maintenance:', error);
        showError('Network error during maintenance prediction');
    } finally {
        showLoading(false);
    }
}

// ============================================================
// Result Display
// ============================================================

function displayIncidentResult(result) {
    const container = document.getElementById('incidentResult');
    
    const severityClass = getSeverityClass(result.severity);
    const confidencePercent = (result.confidence_score * 100).toFixed(0);

    container.innerHTML = `
        <div class="result-item">
            <span class="result-label">Incident Type</span>
            <span class="result-value">${formatIncidentType(result.incident_type)}</span>
        </div>
        <div class="result-item">
            <span class="result-label">Severity</span>
            <span class="badge ${severityClass}">${result.severity}</span>
        </div>
        <div class="result-item">
            <span class="result-label">Confidence</span>
            <div class="confidence-score">
                <div class="confidence-bar">
                    <div class="confidence-fill" style="width: ${confidencePercent}%"></div>
                </div>
                <span class="result-value">${confidencePercent}%</span>
            </div>
        </div>
        <div class="result-item" style="flex-direction: column; align-items: flex-start;">
            <span class="result-label">Expected Impact</span>
            <p style="color: var(--text-primary); margin-top: 0.5rem;">${result.expected_impact}</p>
        </div>
        <div class="result-item" style="flex-direction: column; align-items: flex-start;">
            <span class="result-label">Recommended Actions</span>
            <ul class="actions-list">
                ${result.recommended_actions.map(action => `<li>${action}</li>`).join('')}
            </ul>
        </div>
    `;
}

function displayMaintenanceResult(result) {
    const container = document.getElementById('maintenanceResult');
    
    const riskClass = getSeverityClass(result.risk_level);
    const confidencePercent = (result.confidence_score * 100).toFixed(0);

    container.innerHTML = `
        <div class="result-item">
            <span class="result-label">Risk Level</span>
            <span class="badge ${riskClass}">${result.risk_level}</span>
        </div>
        <div class="result-item">
            <span class="result-label">Urgency</span>
            <span class="result-value">${result.urgency}</span>
        </div>
        <div class="result-item">
            <span class="result-label">Confidence</span>
            <div class="confidence-score">
                <div class="confidence-bar">
                    <div class="confidence-fill" style="width: ${confidencePercent}%"></div>
                </div>
                <span class="result-value">${confidencePercent}%</span>
            </div>
        </div>
        <div class="result-item" style="flex-direction: column; align-items: flex-start;">
            <span class="result-label">Justification</span>
            <p style="color: var(--text-primary); margin-top: 0.5rem;">${result.justification}</p>
        </div>
        <div class="result-item" style="flex-direction: column; align-items: flex-start;">
            <span class="result-label">Recommended Next Steps</span>
            <ul class="actions-list">
                ${result.recommended_next_steps.map(step => `<li>${step}</li>`).join('')}
            </ul>
        </div>
    `;
}

// ============================================================
// Decision History
// ============================================================

async function loadDecisionHistory() {
    const container = document.getElementById('historyContainer');
    const filter = document.getElementById('historyFilter').value;

    container.innerHTML = '<p class="loading">Loading decision history...</p>';

    try {
        let url = 'api/get_decisions.php?limit=20';
        if (filter) {
            url += `&decision_type=${filter}`;
        }

        const response = await fetch(url);
        const data = await response.json();

        if (data.success) {
            displayDecisionHistory(data.data);
        } else {
            container.innerHTML = '<p class="loading">Failed to load decision history</p>';
        }
    } catch (error) {
        console.error('Error loading decision history:', error);
        container.innerHTML = '<p class="loading">Network error loading history</p>';
    }
}

function displayDecisionHistory(decisions) {
    const container = document.getElementById('historyContainer');

    if (decisions.length === 0) {
        container.innerHTML = '<p class="loading">No decisions found</p>';
        return;
    }

    container.innerHTML = decisions.map(decision => {
        const severityClass = getSeverityClass(decision.severity_or_risk);
        const confidencePercent = (decision.confidence_score * 100).toFixed(0);
        const timestamp = new Date(decision.created_at).toLocaleString();

        return `
            <div class="history-item">
                <div class="history-header">
                    <span class="history-road">${decision.road_name}</span>
                    <span class="badge ${severityClass}">${decision.severity_or_risk}</span>
                </div>
                <div class="history-details">
                    <strong>${decision.decision_type.charAt(0).toUpperCase() + decision.decision_type.slice(1)}</strong> • 
                    Confidence: ${confidencePercent}% • 
                    <span class="history-time">${timestamp}</span>
                </div>
            </div>
        `;
    }).join('');
}

// ============================================================
// Utility Functions
// ============================================================

function getSeverityClass(severity) {
    const severityLower = severity.toLowerCase();
    if (severityLower === 'low') return 'badge-low';
    if (severityLower === 'medium') return 'badge-medium';
    if (severityLower === 'high') return 'badge-high';
    if (severityLower === 'critical') return 'badge-critical';
    return 'badge-medium';
}

function formatIncidentType(type) {
    return type.split('_').map(word => 
        word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
}

function showLoading(show) {
    const overlay = document.getElementById('loadingOverlay');
    if (show) {
        overlay.classList.add('active');
    } else {
        overlay.classList.remove('active');
    }
}

function showError(message) {
    alert(`Error: ${message}`);
}

// ============================================================
// Metrics Display
// ============================================================

async function loadMetrics() {
    try {
        const response = await fetch('api/get_metrics.php?days=7');
        const data = await response.json();

        if (data.success) {
            displayMetrics(data.data);
        } else {
            console.error('Metrics API error:', data.error);
        }
    } catch (error) {
        console.error('Error loading metrics:', error);
    }
}

function displayMetrics(metrics) {
    // Congestion Reduction
    const congestionCard = document.getElementById('metricCongestion');
    if (congestionCard) {
        congestionCard.querySelector('.metric-value').textContent = metrics.congestion_reduction.value + '%';
    }

    // Cost Savings
    const costCard = document.getElementById('metricCost');
    if (costCard) {
        costCard.querySelector('.metric-value').textContent = '€' + metrics.cost_savings.formatted;
    }

    // Incidents Handled
    const incidentsCard = document.getElementById('metricIncidents');
    if (incidentsCard) {
        incidentsCard.querySelector('.metric-value').textContent = metrics.incidents_handled.value;
    }

    // Accidents Prevented
    const safetyCard = document.getElementById('metricSafety');
    if (safetyCard) {
        safetyCard.querySelector('.metric-value').textContent = metrics.accidents_prevented.value;
    }
}

// ============================================================
// Decision Summary
// ============================================================

async function generateSummary(roadId, decisionId = null) {
    const container = document.getElementById('summaryContainer');
    container.innerHTML = '<p class="loading">Generating executive summary...</p>';

    try {
        const payload = {
            decision_type: 'summary',
            road_id: roadId
        };

        if (decisionId) {
            payload.decision_id = decisionId;
        }

        const response = await fetch('api/ai_decision_engine.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (data.success) {
            displaySummary(data.data);
        } else {
            container.innerHTML = '<p class="loading">Failed to generate summary: ' + (data.error || 'Unknown error') + '</p>';
        }
    } catch (error) {
        console.error('Error generating summary:', error);
        container.innerHTML = '<p class="loading">Network error</p>';
    }
}

async function loadLatestSummary() {
    try {
        const response = await fetch('api/get_decisions.php?limit=1');
        const data = await response.json();
        
        if (data.success && data.data && data.data.length > 0) {
            const latestDecision = data.data[0];
            // Generate summary for latest decision
            const summaryResponse = await fetch('api/ai_decision_engine.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    decision_type: 'summary',
                    decision_id: latestDecision.id
                })
            });
            
            const summaryData = await summaryResponse.json();
            if (summaryData.success) {
                displaySummary(summaryData.data, latestDecision);
            } else {
                showNoSummaryMessage();
            }
        } else {
            showNoSummaryMessage();
        }
    } catch (error) {
        console.error('Error loading latest summary:', error);
        showNoSummaryMessage();
    }
}

function showNoSummaryMessage() {
    const container = document.getElementById('summaryContainer');
    container.innerHTML = `
        <div class="info-message">
            <p>📊 No decisions yet. To generate a summary:</p>
            <ol style="text-align: left; margin: 1rem 0; color: var(--text-secondary);">
                <li>Select a road from the dropdown above</li>
                <li>Click "Classify Incident" or "Predict Maintenance"</li>
                <li>The AI will analyze and create a decision</li>
                <li>Summary will appear here automatically</li>
            </ol>
        </div>
    `;
}

function displaySummary(summary, decision) {
    const container = document.getElementById('summaryContainer');
    
    const decisionInfo = decision ? `
        <div class="summary-meta" style="margin-bottom: 1rem; padding: 0.75rem; background: rgba(59, 130, 246, 0.1); border-left: 3px solid var(--accent-primary); border-radius: 4px;">
            <strong>${decision.road_name}</strong> • 
            ${decision.decision_type.charAt(0).toUpperCase() + decision.decision_type.slice(1)} • 
            ${new Date(decision.created_at).toLocaleString()}
        </div>
    ` : '';
    
    container.innerHTML = `
        ${decisionInfo}
        <div class="summary-text">${summary.decision_summary}</div>
        <div class="summary-meta">
            <span>Generated by AI Decision Engine</span>
            <span>${new Date().toLocaleString()}</span>
        </div>
    `;
}

// ============================================================
// Incident Alerts Panel
// ============================================================

async function loadActiveIncidents() {
    try {
        const response = await fetch('api/get_active_incidents.php');
        const data = await response.json();

        if (data.success) {
            displayActiveIncidents(data.data, data.count);
        } else {
            console.error('Alerts API error:', data.error);
        }
    } catch (error) {
        console.error('Error loading active incidents:', error);
    }
}

function displayActiveIncidents(incidents, count) {
    const container = document.getElementById('alertsContainer');
    const countBadge = document.getElementById('alertCount');
    
    // Update count badge
    if (countBadge) {
        countBadge.textContent = count;
    }
    
    if (!container) return;
    
    // Show empty state if no incidents
    if (incidents.length === 0) {
        container.innerHTML = `
            <div class="alerts-empty">
                <div class="alerts-empty-icon">✓</div>
                <p>No active incidents</p>
            </div>
        `;
        return;
    }
    
    // Display incident cards
    container.innerHTML = incidents.map(incident => {
        const severityClass = `severity-${incident.severity.toLowerCase()}`;
        const typeIcon = getIncidentTypeIcon(incident.incident_type);
        
        let actionsHTML = '';
        if (incident.recommended_actions && incident.recommended_actions.length > 0) {
            actionsHTML = `
                <div class="alert-actions">
                    ${incident.recommended_actions.map(action => 
                        `<div class="alert-action">${action}</div>`
                    ).join('')}
                </div>
            `;
        }
        
        return `
            <div class="alert-card ${severityClass}">
                <div class="alert-header">
                    <span class="alert-road">${incident.road_name}</span>
                    <span class="alert-time">${incident.time_ago}</span>
                </div>
                <div class="alert-type">${typeIcon} ${formatIncidentType(incident.incident_type)}</div>
                <div class="alert-description">${incident.description}</div>
                <div class="result-item">
                    <span class="result-label">Severity</span>
                    <span class="badge badge-${incident.severity.toLowerCase()}">${incident.severity}</span>
                </div>
                ${actionsHTML}
            </div>
        `;
    }).join('');
}

function getIncidentTypeIcon(type) {
    const icons = {
        'accident': '🚗',
        'breakdown': '🔧',
        'obstruction': '🚧',
        'weather_related': '🌧️',
        'unknown': '⚠️'
    };
    return icons[type] || icons['unknown'];
}

// ============================================================
// Maintenance Overview Panel
// ============================================================

async function loadMaintenanceOverview() {
    try {
        const response = await fetch('api/get_maintenance_overview.php');
        const data = await response.json();

        if (data.success) {
            displayMaintenanceOverview(data.data);
        } else {
            console.error('Maintenance Overview API error:', data.error);
        }
    } catch (error) {
        console.error('Error loading maintenance overview:', error);
    }
}

function displayMaintenanceOverview(data) {
    const container = document.getElementById('maintenanceOverviewContainer');
    const totalSavings = document.getElementById('totalSavings');
    const highRiskCount = document.getElementById('highRiskCount');
    
    // Update summary
    if (totalSavings) {
        totalSavings.textContent = '€' + data.total_savings_formatted;
    }
    if (highRiskCount) {
        highRiskCount.textContent = data.total_roads;
    }
    
    if (!container) return;
    
    // Show empty state if no high-risk roads
    if (data.high_risk_roads.length === 0) {
        container.innerHTML = `
            <div class="alerts-empty">
                <div class="alerts-empty-icon">✓</div>
                <p>No high-risk roads requiring immediate attention</p>
            </div>
        `;
        return;
    }
    
    // Display maintenance road cards
    container.innerHTML = data.high_risk_roads.map(road => {
        const riskClass = `risk-${road.risk_level.toLowerCase()}`;
        
        let nextStepsHTML = '';
        if (road.recommended_next_steps && road.recommended_next_steps.length > 0) {
            nextStepsHTML = `
                <div class="alert-actions">
                    ${road.recommended_next_steps.map(step => 
                        `<div class="alert-action">${step}</div>`
                    ).join('')}
                </div>
            `;
        }
        
        return `
            <div class="maintenance-road-card ${riskClass}">
                <div class="maintenance-header">
                    <span class="maintenance-road-name">${road.road_name}</span>
                    <span class="maintenance-priority">Priority #${road.priority_rank}</span>
                </div>
                
                <div class="maintenance-details">
                    <div class="maintenance-detail-item">
                        <span class="maintenance-detail-label">Risk Level</span>
                        <span class="badge badge-${road.risk_level.toLowerCase()}">${road.risk_level}</span>
                    </div>
                    <div class="maintenance-detail-item">
                        <span class="maintenance-detail-label">Urgency</span>
                        <span class="maintenance-detail-value">${road.urgency}</span>
                    </div>
                    <div class="maintenance-detail-item">
                        <span class="maintenance-detail-label">Length</span>
                        <span class="maintenance-detail-value">${road.length_km} km</span>
                    </div>
                    <div class="maintenance-detail-item">
                        <span class="maintenance-detail-label">Age</span>
                        <span class="maintenance-detail-value">${road.age_years} years</span>
                    </div>
                </div>
                
                <div class="cost-comparison">
                    <div class="cost-item">
                        <span class="cost-label">Early Maintenance</span>
                        <span class="cost-value early">€${formatNumber(road.early_cost)}</span>
                    </div>
                    <div class="cost-item">
                        <span class="cost-label">Emergency Repair</span>
                        <span class="cost-value emergency">€${formatNumber(road.emergency_cost)}</span>
                    </div>
                    <div class="cost-item">
                        <span class="cost-label">Potential Savings</span>
                        <span class="cost-value savings">€${road.potential_savings_formatted}</span>
                    </div>
                </div>
                
                ${nextStepsHTML}
            </div>
        `;
    }).join('');
}

function formatNumber(num) {
    return new Intl.NumberFormat('en-US').format(Math.round(num));
}

// ============================================================
// Simulation Controls
// ============================================================

function setupSimulationControls() {
    const injectBtn = document.getElementById('injectEventBtn');
    const resetBtn = document.getElementById('resetSimBtn');
    const simRoadSelect = document.getElementById('simRoadSelect');
    
    // Populate simulation road select with same roads
    if (simRoadSelect && roads.length > 0) {
        simRoadSelect.innerHTML = roads.map(road => 
            `<option value="${road.id}">${road.name} (${road.location})</option>`
        ).join('');
    }
    
    if (injectBtn) {
        injectBtn.addEventListener('click', injectTestEvent);
    }
    
    if (resetBtn) {
        resetBtn.addEventListener('click', resetSimulation);
    }
}

async function injectTestEvent() {
    const eventType = document.getElementById('simEventType').value;
    const roadId = document.getElementById('simRoadSelect').value;
    const severity = document.getElementById('simSeverity').value;
    const statusDiv = document.getElementById('simStatus');
    
    if (!roadId) {
        showSimStatus('Please select a road', 'error');
        return;
    }
    
    showSimStatus('Injecting test event...', 'info');
    
    try {
        const response = await fetch('api/inject_test_event.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                event_type: eventType,
                road_id: parseInt(roadId),
                severity: severity,
                auto_classify: true
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showSimStatus(`✓ ${data.data.message} (Event ID: ${data.data.incident_id})`, 'success');
            
            // Refresh all panels to show new data
            setTimeout(() => {
                loadActiveIncidents();
                loadDecisionHistory();
                if (eventType === 'vibration') {
                    loadMaintenanceOverview();
                }
            }, 1000);
        } else {
            showSimStatus(`✗ Error: ${data.error}`, 'error');
        }
    } catch (error) {
        console.error('Error injecting test event:', error);
        showSimStatus('✗ Network error', 'error');
    }
}

async function resetSimulation() {
    const statusDiv = document.getElementById('simStatus');
    
    if (!confirm('Are you sure you want to reset the simulation? This will delete recent test data.')) {
        return;
    }
    
    showSimStatus('Resetting simulation...', 'info');
    
    try {
        const response = await fetch('api/reset_simulation.php', {
            method: 'POST'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showSimStatus(`✓ ${data.data.message} (Deleted: ${data.data.incidents_deleted} incidents, ${data.data.decisions_deleted} decisions)`, 'success');
            
            // Refresh all panels
            setTimeout(() => {
                loadActiveIncidents();
                loadDecisionHistory();
                loadMaintenanceOverview();
            }, 1000);
        } else {
            showSimStatus(`✗ Error: ${data.error}`, 'error');
        }
    } catch (error) {
        console.error('Error resetting simulation:', error);
        showSimStatus('✗ Network error', 'error');
    }
}

function showSimStatus(message, type) {
    const statusDiv = document.getElementById('simStatus');
    if (statusDiv) {
        statusDiv.textContent = message;
        statusDiv.className = `sim-status ${type}`;
    }
}
