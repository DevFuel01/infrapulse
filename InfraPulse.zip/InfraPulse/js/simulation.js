
// ============================================================
// Simulation Controls
// ============================================================

function setupSimulationControls() {
    const injectBtn = document.getElementById('injectEventBtn');
    const resetBtn = document.getElementById('resetSimBtn');
    const simRoadSelect = document.getElementById('simRoadSelect');
    
    // Populate simulation road select with same roads
    if (simRoadSelect && roads.length > 0) {
        simRoadSelect.innerHTML = roads.map(road => 
            `<option value="${road.id}">${road.name} (${road.location})</option>`
        ).join('');
    }
    
    if (injectBtn) {
        injectBtn.addEventListener('click', injectTestEvent);
    }
    
    if (resetBtn) {
        resetBtn.addEventListener('click', resetSimulation);
    }
}

async function injectTestEvent() {
    const eventType = document.getElementById('simEventType').value;
    const roadId = document.getElementById('simRoadSelect').value;
    const severity = document.getElementById('simSeverity').value;
    const statusDiv = document.getElementById('simStatus');
    
    if (!roadId) {
        showSimStatus('Please select a road', 'error');
        return;
    }
    
    showSimStatus('Injecting test event...', 'info');
    
    try {
        const response = await fetch('api/inject_test_event.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                event_type: eventType,
                road_id: parseInt(roadId),
                severity: severity,
                auto_classify: true
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showSimStatus(`✓ ${data.data.message} (Event ID: ${data.data.incident_id})`, 'success');
            
            // Refresh all panels to show new data
            setTimeout(() => {
                loadActiveIncidents();
                loadDecisionHistory();
                if (eventType === 'vibration') {
                    loadMaintenanceOverview();
                }
            }, 1000);
        } else {
            showSimStatus(`✗ Error: ${data.error}`, 'error');
        }
    } catch (error) {
        console.error('Error injecting test event:', error);
        showSimStatus('✗ Network error', 'error');
    }
}

async function resetSimulation() {
    const statusDiv = document.getElementById('simStatus');
    
    if (!confirm('Are you sure you want to reset the simulation? This will delete recent test data.')) {
        return;
    }
    
    showSimStatus('Resetting simulation...', 'info');
    
    try {
        const response = await fetch('api/reset_simulation.php', {
            method: 'POST'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showSimStatus(`✓ ${data.data.message} (Deleted: ${data.data.incidents_deleted} incidents, ${data.data.decisions_deleted} decisions)`, 'success');
            
            // Refresh all panels
            setTimeout(() => {
                loadActiveIncidents();
                loadDecisionHistory();
                loadMaintenanceOverview();
            }, 1000);
        } else {
            showSimStatus(`✗ Error: ${data.error}`, 'error');
        }
    } catch (error) {
        console.error('Error resetting simulation:', error);
        showSimStatus('✗ Network error', 'error');
    }
}

function showSimStatus(message, type) {
    const statusDiv = document.getElementById('simStatus');
    if (statusDiv) {
        statusDiv.textContent = message;
        statusDiv.className = `sim-status ${type}`;
    }
}
