
// ============================================================
// Incident Alerts Panel
// ============================================================

async function loadActiveIncidents() {
    try {
        const response = await fetch('api/get_active_incidents.php');
        const data = await response.json();

        if (data.success) {
            displayActiveIncidents(data.data, data.count);
        } else {
            console.error('Alerts API error:', data.error);
        }
    } catch (error) {
        console.error('Error loading active incidents:', error);
    }
}

function displayActiveIncidents(incidents, count) {
    const container = document.getElementById('alertsContainer');
    const countBadge = document.getElementById('alertCount');
    
    // Update count badge
    if (countBadge) {
        countBadge.textContent = count;
    }
    
    if (!container) return;
    
    // Show empty state if no incidents
    if (incidents.length === 0) {
        container.innerHTML = `
            <div class="alerts-empty">
                <div class="alerts-empty-icon">✓</div>
                <p>No active incidents</p>
            </div>
        `;
        return;
    }
    
    // Display incident cards
    container.innerHTML = incidents.map(incident => {
        const severityClass = `severity-${incident.severity.toLowerCase()}`;
        const typeIcon = getIncidentTypeIcon(incident.incident_type);
        
        let actionsHTML = '';
        if (incident.recommended_actions && incident.recommended_actions.length > 0) {
            actionsHTML = `
                <div class="alert-actions">
                    ${incident.recommended_actions.map(action => 
                        `<div class="alert-action">${action}</div>`
                    ).join('')}
                </div>
            `;
        }
        
        return `
            <div class="alert-card ${severityClass}">
                <div class="alert-header">
                    <span class="alert-road">${incident.road_name}</span>
                    <span class="alert-time">${incident.time_ago}</span>
                </div>
                <div class="alert-type">${typeIcon} ${formatIncidentType(incident.incident_type)}</div>
                <div class="alert-description">${incident.description}</div>
                <div class="result-item">
                    <span class="result-label">Severity</span>
                    <span class="badge badge-${incident.severity.toLowerCase()}">${incident.severity}</span>
                </div>
                ${actionsHTML}
            </div>
        `;
    }).join('');
}

function getIncidentTypeIcon(type) {
    const icons = {
        'accident': '🚗',
        'breakdown': '🔧',
        'obstruction': '🚧',
        'weather_related': '🌧️',
        'unknown': '⚠️'
    };
    return icons[type] || icons['unknown'];
}
