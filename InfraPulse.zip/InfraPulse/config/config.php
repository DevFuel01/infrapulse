<?php

/**
 * InfraPulse - System Configuration
 * Environment settings and API keys
 */

// Error reporting for development
error_reporting(E_ALL);
ini_set('display_errors', 0); // Set to 0 in production
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/error.log');

// Timezone
date_default_timezone_set('UTC');

// CORS headers for API
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=UTF-8');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Gemini API Configuration
define('GEMINI_API_KEY', '');
define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent');

// System Constants
define('APP_NAME', 'InfraPulse');
define('APP_VERSION', '1.0.0');
define('MAX_CONFIDENCE_SCORE', 1.0);
define('MIN_CONFIDENCE_SCORE', 0.0);

// Database Configuration (imported from database.php)
require_once __DIR__ . '/database.php';
