-- ================================================================
-- Add Current Incidents for Demo (January 21, 2026)
-- Run this to add fresh incidents for testing
-- ================================================================

USE infrapulse;

-- Add current incidents (today's date)
INSERT INTO incident_reports (road_id, description, source, reported_at) VALUES
-- M1 Motorway - Active accident
(1, 'Multi-vehicle collision reported at Junction 23. Three vehicles involved, emergency services on scene. Heavy traffic buildup extending 5km northbound.', 'operator', NOW() - INTERVAL 30 MINUTE),

-- A40 Urban - Breakdown
(2, 'Large delivery truck broken down in left lane near Perivale. Partially blocking traffic flow. Recovery vehicle dispatched.', 'system', NOW() - INTERVAL 1 HOUR),

-- B4632 Rural - Weather related
(3, 'Fallen tree branches blocking half of carriageway after overnight storm. Road still passable but hazardous.', 'public', NOW() - INTERVAL 2 HOUR),

-- M25 Orbital - Severe congestion
(4, 'Severe congestion due to earlier incident now cleared. Residual delays expected for 2+ hours. No current obstruction.', 'operator', NOW() - INTERVAL 45 MINUTE);

-- Add current traffic events
INSERT INTO traffic_events (road_id, avg_speed_kmh, traffic_volume, congestion_level, recorded_at) VALUES
(1, 25.3, 12000, 'high', NOW() - INTERVAL 15 MINUTE),
(2, 18.5, 9500, 'high', NOW() - INTERVAL 20 MINUTE),
(3, 45.2, 650, 'medium', NOW() - INTERVAL 10 MINUTE),
(4, 32.1, 13500, 'high', NOW() - INTERVAL 25 MINUTE);

-- Add current weather logs
INSERT INTO weather_logs (road_id, weather_condition, temperature_c, recorded_at) VALUES
(1, 'clear', 9.2, NOW() - INTERVAL 30 MINUTE),
(2, 'rain', 8.5, NOW() - INTERVAL 20 MINUTE),
(3, 'storm', 7.1, NOW() - INTERVAL 1 HOUR),
(4, 'rain', 8.8, NOW() - INTERVAL 30 MINUTE);

SELECT 'Current incidents added successfully!' AS status;
